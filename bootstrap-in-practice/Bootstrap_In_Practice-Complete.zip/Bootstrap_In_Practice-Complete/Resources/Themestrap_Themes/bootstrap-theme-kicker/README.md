# Kicker

**Kicker** is a theme for Bootstrap 3, built upon Themestrap, which uses colors from the Kick Ass movies.

## Quick Install

Get `dist/css/bootstrap.min.css` or `dist/css/bootstrap.css` and use it to replace the original from Bootstrap.

## How to modify

Check [Themestrap](https://github.com/divshot/themestrap)'s `README.md`.

## Credits

Author: William Ghelfi <william@williamghelfi.com>

You got a copy of this theme because you purchased the Complete Package of [*Bootstrap in Practice*](http://www.williamghelfi.com/bootstrap-in-practice).

So, Thank you!

## Copyright and license

For Themestrap: Copyright 2013 Divshot, Inc. under [the Apache 2.0 license](LICENSE).

For Kicker: Copyright 2013 [William Ghelfi](http://www.williamghelfi.com/). under [the Apache 2.0 license](LICENSE).