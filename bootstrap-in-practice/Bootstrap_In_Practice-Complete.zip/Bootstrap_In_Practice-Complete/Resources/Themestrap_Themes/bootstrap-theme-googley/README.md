# Googley

**Googley** is a theme for Bootstrap 3, built upon Themestrap, which loosely resembles the looks of Google web applications like Google Plus and Gmail.

## Quick Install

Get `dist/css/bootstrap.min.css` or `dist/css/bootstrap.css` and use it to replace the original from Bootstrap.

## Things to know

For the complete look, you'll need to add the proper webfont to your HTML:

```
<link href="//fonts.googleapis.com/css?family=Roboto:400,500,400italic,500italic,700,700italic" rel="stylesheet" />
```

## How to modify

Check [Themestrap](https://github.com/divshot/themestrap)'s `README.md`.

## Credits

Author: William Ghelfi <william@williamghelfi.com>

You got a copy of this theme because you purchased the Complete Package of [*Bootstrap in Practice*](http://www.williamghelfi.com/bootstrap-in-practice).

So, Thank you!

## Copyright and license

For Themestrap: Copyright 2013 Divshot, Inc. under [the Apache 2.0 license](LICENSE).

For Googley: Copyright 2013 [William Ghelfi](http://www.williamghelfi.com/). under [the Apache 2.0 license](LICENSE).