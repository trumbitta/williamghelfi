# Bootstrap In Practice

## Chapter 8 - Create, Update, Delete, (Hit) List

This is a Git repository of the code example from Chapter 8 of Bootstrap In Practice.

Each of the incremental steps covered in the book are reproduced as a single commit.  
This means you can follow the book and check the code here, or use it as a reference for future works.

### About Git

* [Official website](http://git-scm.com/)
* [Try Git](http://try.github.io/)
* [Pro Git: the book](http://git-scm.com/book)

### License

Use this code as you want. If you'll ever redistribute it, I'd like to be mentioned as the original author:

William Ghelfi <william@williamghelfi.com> - Twitter: @trumbitta - http://www.williamghelfi.com/bootstrap-in-practice